package chap3;

public class prac4 {

	public static void main(String[] args) {
		int num=456;
		
		System.out.println((int)((float)(num/100)*100));
	}

}
