package ex1;

public class ex {

	public static void main(String[] args) {
		
	}

}
