package prac;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int N=sc.nextInt();
		int a,b,sum=0;
		if(N<10)
			N*=10;//주어진 숫자를 두자리수로 만듦
		a=N/10;//10의자리 수
		b=N%10;//1의자리 수
		sum=a+b;// 새로운 수 만듦
	}

}
