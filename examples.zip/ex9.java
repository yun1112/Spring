package chap3;

public class ex9 {

	public static void main(String[] args) {
		int mul=1;
		for (int i = 0; i < 10; i++) {
			mul*=(i+1);
		}
		System.out.println(mul);
	}

}
