package ex1;

public class ex1 {

	public static void main(String[] args) {
		int num=100;
		boolean a = true, b = false;
		System.out.println(a);
		System.out.println(b);
		System.out.println(4>3);
		System.out.println(4<3);
		System.out.println(num>20);
		
		
		int n=0;
		System.out.println(n);
	}

}
