package example;

public class Method1 {

	public static void main(String[] args) {

	}
	void add() {
		
	}
}
