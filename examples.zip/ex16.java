package chap3;

public class ex16 {

	public static void main(String[] args) {
		int i = 1, sum = 0;
		while (true) {
			sum += i;
			i++;

			if (i > 100)
				break;

		}
		System.out.println(sum);
	}

}
