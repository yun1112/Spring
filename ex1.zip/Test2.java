package ex1;

public class Test2 {

	public static void main(String[] args) {

		System.out.println(15);
		System.out.println("15");
		System.out.println(10 + 5);
		System.out.println(1 + "5");
		System.out.println("1" + "5");

	}
}
