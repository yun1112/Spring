package chap3;

public class ex4 {

	public static void main(String[] args) {
		int n = 3;
		if (n == 1) {
			System.out.println("Simple Java");
			System.out.println("Do you like coffee?");
		} else if (n == 2) {
			System.out.println("Funny Java");
			System.out.println("Do you like coffee?");
		} else if (n == 3) {
			System.out.println("Fantastic Java");
			System.out.println("Do you like coffee?");
		} else {
			System.out.println("The best programming language");
			System.out.println("Do you like coffee?");
		}

	}
}