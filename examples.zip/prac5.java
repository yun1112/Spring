package chap3;

public class prac5 {

	public static void main(String[] args) {
		int num=333;
		System.out.println((int)(float)(num/10)*10+1);
	}

}
