package ex1;

public class example2 {

	public static void main(String[] args) {
		double num1, num2, result = 0.0;
		num1 = 1.0000001;
		num2 = 2.0000001;
//		result = num1 + num2;
		result = num1 * num2;
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(result); 
	}

}
