package chap3;

public class ex13 {

	public static void main(String[] args) {
		int result=0;
		for (int i = 2; i < 10; i++) {
			for (int j = 2; j < 10; j++) {
				result=i*j;
				
				if(i%2==0)
					System.out.println(result);
				
			}
		}
	}
}
