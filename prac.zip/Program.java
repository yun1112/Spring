package prac;

public class Program {

	public static void main(String[] args) {
		MemberManager mm=new MemberManager();
		mm.Run();
	}

}
