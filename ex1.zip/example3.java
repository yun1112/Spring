package ex1;

public class example3 {

	public static void main(String[] args) {
		char ch1 = 'A', ch2 = '한';
		char ch3 = 66;
		System.out.println(ch1);
		System.out.println(ch3);
		System.out.println(ch2);
	}

}
