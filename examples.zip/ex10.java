package chap3;

public class ex10 {

	public static void main(String[] args) {
		int num=1;
		for (int i = 0; i < 9; i++) {
			num=(i+1)*5;
			System.out.println(num);
		}
	}

}
