package chap3;

public class ex14 {

	public static void main(String[] args) {
		 int x,y;
		 
		 
	}

}
