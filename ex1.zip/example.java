package ex1;

public class example {

	public static void main(String[] args) {
		int num1=10,num2=20,num3;
		num3=num1+num2;
		System.out.println(num3);
	}

}
