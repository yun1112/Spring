package chap3;

public class prac3 {

	public static void main(String[] args) {
		int num=10;
		
		System.out.println((num)>0 ? "양수":"음수");
	}

}
