package ex1;

public class Test1 {

	public static void main(String[] args) {
		/*
		 * 문제1. 다음 두문장을 출력하는 프로그램 작성
		 * 
		 * 
		 * 
		 */
		System.out.println("2+5=" + 2 + 5);
		System.out.println("2+5=" + (2 + 5));
	}

}
